'use strict';
app.config(function($routeProvider) {
  $routeProvider.when('/history', {templateUrl: 'tabs/history.html', controller: 'controller', reloadOnSearch: false});
  $routeProvider.when('/scada', {templateUrl: 'tabs/scada.html', controller: 'controller', reloadOnSearch: false});
  $routeProvider.otherwise({redirectTo: '/scada'});
});
app.controller('controller',
  function controller($scope, tagweb) {
    // Function to update our model with new data
    var update = function(data) {
      for (var i in data) {
        $scope[data[i].name] = {value: data[i].value, type: data[i].type, name: data[i].name}
      }
    };
    // Get controls' default values and poll indicators
    tagweb.get('controls', update);
    tagweb.poll('indicators', update);
    // Write new data to the LabVIEW server
    $scope.push = function(object) {tagweb.put(object)};
    // Chart functionality
    var pushChart = function(chart, x) {
      if (x) {
        var data = {x: x.value}
        for (var i = 0; i < chart.options.series.length; i++) {
          data[chart.options.series[i].y] = $scope[chart.options.series[i].y].value;
          console.log($scope[chart.options.series[i].y].name);
        }
        chart.data.push(data);
        if (chart.data.length > 100) {chart.data.shift()}
      }
    }
    // Insert Temperature Chart
    $scope.temperature = {data: [], options: {drawDots: false, series: 
      [{y: 'temperature1'}, {y: 'temperature2'}, {y: 'temperature3'}]}};
    $scope.$watch('temperaturex.value', function(newVal) {
      pushChart($scope.temperature, $scope.temperaturex)
    });
    // Insert Tank Chart
    $scope.tank = {data: [], options: {drawDots: false, series: 
      [{y: 'tank1'}, {y: 'tank2'}, {y: 'tank3'}]}};
    $scope.$watch('tankx.value', function(newVal) {
      pushChart($scope.tank, $scope.tankx)
    });
  }
);
app.directive('tank', function ($compile) {
  return {
    restrict: 'E',
    template: '<div class="tank">&nbsp;</div>',
    require: 'ngModel',
    link: function(scope, elm, attrs, ctrl) {
      ctrl.$render = function() {
        if (ctrl.$viewValue.value) {
          var tankPosition = 554 - ctrl.$viewValue.value
          elm.children()[0].style.position = 'absolute'
          elm.children()[0].style.top = tankPosition.toString() + 'px';
          elm.children()[0].style.height = ctrl.$viewValue.value.toString() + 'px'}
      };
      ctrl.$setViewValue(ctrl.$viewValue);
    }
  };
});
app.directive('boolean', function() {
  return {
    restrict: 'E',
    template: '<a class="btn btn-primary">On</a>',
    require: 'ngModel',
    link: function(scope, elm, attrs, ctrl) {
      ctrl.toggle = function(elm) {
        if (ctrl.$viewValue.value) {elm.children()[0].text = 'On'}
          else {elm.children()[0].text = 'Off'}
      }
      elm.on('click', function() {
        scope.$apply(function() {
          ctrl.$setViewValue(
            {type: 'Boolean', value: !(ctrl.$viewValue.value), name: ctrl.$viewValue.name});
          ctrl.toggle(elm);
        });
        scope.push(ctrl.$viewValue);
      });
      ctrl.$render = function() {ctrl.toggle(elm)};
      ctrl.$setViewValue({type: 'Boolean', value: false,  name: ctrl.$viewValue.name});
    }
  };
});
app.directive('numeric', function ($compile) {
  return {
    restrict: 'E',
    template: '<input type="number" class="numeric form-control" />',
    require: 'ngModel',
    link: function(scope, elm, attrs, ctrl) {
      elm.on('change', function() {
        scope.$apply(function() {
          ctrl.$setViewValue({
            type: ctrl.$viewValue.type,
            value: elm.children()[0].value,
            name: ctrl.$viewValue.name});
        });
        scope.push(ctrl.$viewValue);
      });
      // Round numeric to one decimal place by multiplying / dividing by 10
      ctrl.$render = function() {elm.children()[0].value = 
        Math.round(ctrl.$viewValue.value * 10) / 10};
      ctrl.$setViewValue(ctrl.$viewValue);
    }
  };
});