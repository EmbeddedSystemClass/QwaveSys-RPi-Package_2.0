'use strict';
var app = angular.module('niApp', ['ngRoute', 'n3-line-chart']); // 
// This service handles communication with the web server
app.factory('tagweb', ['$http', '$timeout', function($http, $timeout) {
    // Set the default polling rate
    var rate = 100;
    // Get a group of tags, parse them, and call the callback function
    var get = function(group, callback) {
      $http.get('/tagweb/groups/' + group).success(function(data) {
        for(var i in data) {
          switch(data[i].type) {
            case 'Boolean': data[i].value = data[i].value == 'TRUE'; break;
            case 'Double': data[i].value = parseFloat(data[i].value); break;
            default: data[i].value = parseInt(data[i].value); break;
          }
        }
        callback(data);
      });
    }
    return {
      // Continuously gets groups at given rate
      poll: function(group, callback) {
        var poller = function() {
          get(group, callback);
          setTimeout(poller, rate);
        };
        poller();
      },
      // Get groups of tags only once
      get: function(group, callback) {get(group, callback)},
      // Write tag to web server
      put: function(object) {
        $http.put('/tagweb/tags/' + object.name + '?type=' + object.type, object.value.toString());
      }
    }
}]);
app.directive('string', function ($compile) {
  return {
    restrict: 'E',
    template: '<input type="text" class="string form-control" />',
    require: 'ngModel',
    link: function(scope, elm, attrs, ctrl) {
      elm.on('change', function() {
        scope.$apply(function() {
          ctrl.$setViewValue({
            type: ctrl.$viewValue.type,
            value: elm.children()[0].value,
            name: ctrl.$viewValue.name});
        });
        scope.push(ctrl.$viewValue);
      });
      ctrl.$render = function() {elm.children()[0].value = ctrl.$viewValue.value};
      ctrl.$setViewValue(ctrl.$viewValue);
    }
  };
});
app.directive('led', function ($compile) {
  return {
    restrict: 'E',
    template: '<div class="led">&nbsp;</div>',
    require: 'ngModel',
    link: function(scope, elm, attrs, ctrl) {
      ctrl.$render = function() {
        console.log();
        if (ctrl.$viewValue.value == true) {
          elm.children()[0].style.backgroundColor = '#6f6';
        } else {
          elm.children()[0].style.backgroundColor = '#393';
        }
      };
      ctrl.$setViewValue(ctrl.$viewValue);
    }
  };
});
app.directive('chart', function ($compile) {
  return {
    restrict: 'E',
    template: '<input type="number" class="chart form-control" />',
    require: 'ngModel',
    link: function(scope, elm, attrs, ctrl) {
      elm.on('change', function() {
        scope.$apply(function() {
          ctrl.$setViewValue({
            type: ctrl.$viewValue.type,
            value: elm.children()[0].value,
            name: ctrl.$viewValue.name});
        });
        scope.push(ctrl.$viewValue);
      });
      ctrl.$render = function() {elm.children()[0].value = ctrl.$viewValue.value};
      ctrl.$setViewValue(ctrl.$viewValue);
    }
  };
});