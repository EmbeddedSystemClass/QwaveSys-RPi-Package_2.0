1. Install "ni_lib_cvt-3.3.0.13.vip"
2. Install "ni_cvt_web_addon-1.6.0.1.vip"
3. Install "ni_lib_tagwebclient-1.5.0.1.vip"

4. Goto "C:\Program Files (x86)\National Instruments\LabVIEW 2014\vi.lib\NI\TagWebClient\sample web service\private" , 
Replace "get system info.vi" with new one from "get system info_Modified.zip" 


5. Goto "C:\Program Files (x86)\National Instruments\LabVIEW 2014\vi.lib\NI\CVT Web Addon"
Replace "API" folder with new one from "API_Modified.zip"

