
$(document).ready(function() {
	//Initialize graph max and mins
	var bounds = { xMin: 0, xMax:0, yMin:0, yMax:0 };
	
	//Initialize channels for graph
	var ch0 = { id: '#Ch_0', URL: "", active: 0, data: [], number: 0, bounds: bounds };
	var ch1 = {	id: '#Ch_1', URL: "", active: 0, data: [], number: 1, bounds: bounds };
	var ch2 = {	id: '#Ch_2', URL: "", active: 0, data: [], number: 2, bounds: bounds };
	var ch3 = { id: '#Ch_3', URL: "", active: 0, data: [], number: 3, bounds: bounds };
	
	//use index to iterate current point in the array
	var index = 0;
	
	//Write 100 points of zeroes to each channel
	for(var i = -100; i < index; i++) {
		ch0.data.push([i,0]);
		ch1.data.push([i,0]);
		ch2.data.push([i,0]);
		ch3.data.push([i,0]);
	}

	//window.setInterval(graphDriver, 200);

	//Populate dropdown menus
	createDropdowns();

	//create a new plot named oscope, and attach each channel's data to it.
	var oscope = plotConfig([ch0.data, ch1.data, ch2.data, ch3.data]);
	
	//Get new URL for each channel when a dropdown changes
	getURL(ch0);
	getURL(ch1);
	getURL(ch2);
	getURL(ch3);
	
	graphDriver();
	
	function graphDriver(){
		//get a new data point for the plot, channel, and index.
		updateChannel(oscope, ch0, index);
		updateChannel(oscope, ch1, index);
		updateChannel(oscope, ch2, index);
		updateChannel(oscope, ch3, index);

		//go to next index
		index++;
			
		//refresh graph	
		refreshPlot(oscope, bounds);
		setTimeout(function(){graphDriver();},document.getElementById("Rate").value);
	}
});

function createDropdowns(){
	//Channel select text
	var ChSelect = '<option>none</option>';
	$.getJSON('tags', function(data){
		//cycle through the groups in the database, and write them to the drop-down category menus
		for (var group_index = 0 ; group_index < data.length ; group_index++){
			ChSelect += '<optgroup label ='+data[group_index].groupName+'>';
				
			//for loop cycles through each tag array
			for(var tags_index = 0 ; tags_index < data[group_index].Tags.length ; tags_index++ ){
			
				//for loop cycles through each tagName and assigns it to dropdown.
				for( var names_index = 0 ; names_index < data[group_index].Tags[tags_index].tags.length ; names_index++){
					ChSelect += '<option value='+data[group_index].Tags[tags_index].type+'>'+ data[group_index].Tags[tags_index].tags[names_index].tagName+'</option>';
				}
			}
			//Close each option group
			ChSelect += '</optgroup>';
		} 

		//Write menus
		$("#Ch_0").html(ChSelect);
		$("#Ch_1").html(ChSelect);
		$("#Ch_2").html(ChSelect);
		$("#Ch_3").html(ChSelect);
		$("#Ch_0").css('color', 'red');
		$("#Ch_1").css('color', 'blue');
		$("#Ch_2").css('color', 'orange');
		$("#Ch_3").css('color', 'green');


	});
}

function updateChannel(plot, ch, index){
	if ($(ch.id).val() != 'none'){ //run when graph is active
		ch.active = 1;
		$.getJSON(ch.URL , function(data){
					

			if($(ch.id).val() == 'Boolean'){
				switch(data.value){
					case 'TRUE':
					ch.data.push([index,1]);
					break;
					case 'FALSE':
					ch.data.push([index,0]);
					break;
				}// end switch
				plot.series[ch.number].yaxis = 'y2axis';
			}
			else{
				ch.data.push([index, parseFloat(data.value)]);
				plot.series[ch.number].yaxis = 'yaxis';
			}
			plot.series[ch.number].show = true;
			ch.data.shift();
			plot.series[ch.number].data=ch.data;
			
			//check limit
			if ( ch.bounds.xMax < (plot.series[ch.number].data[99][0])){
				ch.bounds.xMax = plot.series[ch.number].data[99][0];
			}
			if ( ch.bounds.xMin < (plot.series[ch.number].data[0][0])){
				ch.bounds.xMin = plot.series[ch.number].data[0][0];
			}
		});
	} 
	else{ // turn off if selector 0 is equal to 'none'
		ch.active = 0;
		plot.series[ch.number].show = false;
		ch.data.push([index,0]);
		ch.data.shift();
		plot.series[ch.number].data=ch.data;
	}
}

function plotConfig(channels){
	return $.jqplot("chart1", channels,
	{ 
		axes: {
		xaxis: {
			tickOptions: {
				show: false
			},
			rendererOptions: {
				drawBaseline: false
			}
		}
	},
	grid: {
		backgroundColor: 'white'
	},
	series: [
		{
			showMarker: false,
			fill: false,
			alpha: .09,
			neighborThreshold: 3,
			lineWidth: 2.2,
			color: 'red',
		},
		{
			showMarker: false,
			fill: false,
			alpha: .09,
			neighborThreshold: 3,
			lineWidth: 2.2,
			color: 'blue',
		},
		{
			showMarker: false,
			fill: false,
			alpha: .09,
			neighborThreshold: 3,
			lineWidth: 2.2,
			color: 'orange',
		},
		{
			showMarker: false,
			fill: false,
			alpha: .09,
			neighborThreshold: 3,
			lineWidth: 2.2,
			color: 'green',
		}
	]
	});
}

function getURL(ch) {
	$(ch.id).change(function(){
	ch.URL = 'tags/'+$(ch.id + " :selected").text()+'?type='+$(ch.id).val();
	});	
}	

function refreshPlot(plot, bounds){
		plot.resetAxesScale();
		plot.axes.xaxis.min = bounds.xMin;
		plot.axes.xaxis.max = bounds.xMax;
		plot.replot( );
}