
$(document).ready(function()
{
	var groupList = null; //groupList is used to hold the list of tag groups in the system
	var tagsDrawn = null; //value contains the value of all variables in the table
	var polling=document.getElementById("EnablePolling");
	// Call TagBrowse to get a list of all Tags currently available.
	$.getJSON('tags', function(data){
		updateTable(); //refresh table
		$("#GroupSelect").change(updateTable); //attach update to value change on group select
		$("#Submit").click(submitValues); 
		$("#EnablePolling").change(checkPolling);
	});
	
	
	function checkPolling()
	{
		if (polling.checked==true) {
			updateData();
		}
	}
	
	
	function updateTable()
	{
		//Get list of all tags and their properties from the database
		$.getJSON("tags", function(data){
			for( var i = 0 ; i < data.length ; i++ )
			{
			//Cycle through each group in data and add it to the group_list
				groupList += '<option value="'+i+'">'+data[i].groupName+'</option>';
			}
			//$.each(data, function(){groupList += '<option>'+this.groupName+'</option>';}); //cycle through groups and add them to dropdown
			
			$("#GroupSelect").html(groupList);//Add groupList to GroupSelect in Tags.html and make table

			var group;
			var tbl_row="<tbody>";
			$("#ResultsTable tbody tr").remove();
			
			var index = 0;
			/*
			 * &index is used to keep track of master location in the group.
			 * TagBrowse returns an array of arrays, one for each datatype, so
			 * index is used to keep track of the table row. 
			 */
				
			//Get currently selected group
			group = $("#GroupSelect")[0].selectedIndex;
				
			if (group>=0) {
				tagsDrawn=data[group].Tags;
				//Cycle through each tag group (organized by data type)
				$.each(tagsDrawn, function() {	
					var currtype = this.type; //get type of group
					
					$.each(this.tags, function(i,v){ //Cycle through each tag in the group
						index++; //increase index
						var tagID="js"+v.tagName+"WriteVal";
						if (v.permissions == "R/W"){ //check for read permission
							tbl_row += "<tr><td>"+currtype+"</td><td>"+v.tagName+"</td><td id=\"js"+v.tagName+"ReadVal\">"+"</td><td><input type=\"text\" id=\""+tagID+"\" datatype="+currtype+">"+"</input></td></tr>";
						} 
						else if (v.permissions == "-/W") {
							tbl_row += "<tr><td>"+currtype+"</td><td>"+v.tagName+"</td><td>Read Access Denied</td><td><input type=\"text\" id=\""+tagID+"\" datatype="+currtype+">"+"</input></td></tr>";
						}
						else if (v.permissions == "R/-") {
							tbl_row += "<tr><td>"+currtype+"</td><td>"+v.tagName+"</td><td id=\"js"+v.tagName+"ReadVal\">"+"</td><td>Write Access Denied</td></tr>";
						}
						else { //if the tag is not readable
						}				
						
					});	
				});
				tbl_row+="</tbody>";
				$("#ResultsTable > tbody").replaceWith(tbl_row);
				
				$.each(tagsDrawn, function() {	
					var currtype = this.type; //get type of group
					
					$.each(this.tags, function(i,v){ //Cycle through each tag in the group
						index++; //increase index
						var tagID="js"+v.tagName+"WriteVal";
						if (v.permissions == "R/W" || v.permissions == "-/W"){ //check for read permission
							document.getElementById(tagID).addEventListener("change", function(e){
								var toSet=e.srcElement;
								var ttype=toSet.parentNode.parentNode.firstChild.innerHTML;
								var tname=e.srcElement.id.substring(2,(e.srcElement.id.length-("WriteVal").length));
								$.ajax({
									url: "tags/"+tname+"?type="+ttype,
									type: 'PUT',
									dataType: 'json',
									data: toSet.value,
									success: function (data, textStatus, xhr) {
										var turl="tags/"+tname+"?type="+ttype;
										toSet.value="";
										$.get(turl, 
											function(idv){
												document.getElementById("js"+tname+"ReadVal").innerHTML=idv.value;
											}
										);	
									}
								});
							});
						} 
						else { //if the tag is not readable
						}				
					});	
				});
				updateData();
			}
			else 
			{
				setTimeout(updateTable,1000);
			}
		});
	}
	


	function updateData() {
		var index = 0;
		
		try {
			//Cycle through each tag group (organized by data type)
			$.each(tagsDrawn, function() {	
				var ctype = this.type; //get type of group
				
				$.each(this.tags, function(i,v){ //Cycle through each tag in the group
					index++; //increase index
					if (v.permissions == "R/W" || v.permissions == "R/-"){ //check for read permission
						var turl="tags/"+v.tagName+"?type="+ctype;
						$.get(turl, 
							function(idv){
								document.getElementById("js"+v.tagName+"ReadVal").innerHTML=idv.value;
							}
						);	
					} else { //if the tag is not readable

					}
				});	
			});
		}
		catch (e) {
		}
		finally {
			
		}

		if (polling.checked==true) {
			setTimeout(updateData,document.getElementById("Rate").value);
		}
	}
	
	
	function submitValues() {
	
		var index = 0;
		var turl="";
		
		try {
			//Cycle through each tag group (organized by data type)
			$.each(tagsDrawn, function() {	
				var ctype = this.type; //get type of group
				
				$.each(this.tags, function(i,v){ //Cycle through each tag in the group
					index++; //increase index
					if (v.permissions == "R/W" || v.permissions == "-/W"){ //check for read permission
						var toSet=document.getElementById("js"+v.tagName+"WriteVal");
						if (toSet.value != "") 
						{
							$.ajax({
								url: "tags/"+v.tagName+"?type="+ctype,
								type: 'PUT',
								dataType: 'json',
								data: toSet.value,
								success: function (data, textStatus, xhr) {
									var turl="tags/"+v.tagName+"?type="+ctype;
									$.get(turl, 
										function(idv){
											document.getElementById("js"+v.tagName+"ReadVal").innerHTML=idv.value;
										}
									);	
								}
							});
						}
						toSet.value="";
					} else { //if the tag is not writeable

					}
				});	
			});
		}
		catch (e) {
		}
		finally {
		}
		
	}
});