$(document).ready(function getCPU()
{
	$.getJSON('system' , function(data){
		$("#CPU_Bar").width(data.CPU+'%');
		$("#CPU_Bar").html(data.CPU+'%');
		$("#CPU_Bar").css('color', 'black');
		$("#Mem_Bar").width(data.FreeMemoryPercent+'%');
		$("#Mem_Bar").html((data.TotalMemory - data.FreeMemory)+'/'+data.TotalMemory);
		$("#Mem_Bar").css('color', 'black');
		$("#CPU").css('color', 'black');
	});
	setTimeout(getCPU, 750);
});