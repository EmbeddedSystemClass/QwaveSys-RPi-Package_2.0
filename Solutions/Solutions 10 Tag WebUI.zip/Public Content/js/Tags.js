
$(document).ready(function()
	{
		//$.ajaxSetup({ async: false }); //Disable asynchronous web calls to ensure that URL requests happen when called.
		var groupList = null; //groupList is used to hold the list of tag groups in the system
		var tagsDrawn = null; //value contains the value of all variables in the table
		$.getJSON('tags', function(data){ //get results from TagBrowse
			//attach updateTable to a value change on GroupSelect
			$("#GroupSelect").change(updateTable);
			updateTable();
			updateData(); //update Table to show values
		});
		

		function updateData() {
			var index = 0;
			var turl="";
			try {
				//Cycle through each tag group (organized by data type)
				$.each(tagsDrawn, function() {	
					var ctype = this.type; //get type of group
					
					$.each(this.tags, function(i,v){ //Cycle through each tag in the group
						index++; //increase index
						if (v.permissions == "R/W" || v.permissions == "R/-"){ //check for read permission
							turl="tags/"+v.tagName+"?type="+ctype;
							$.get(turl, 
								function(idv){
									document.getElementById(v.tagName).innerHTML=idv.value;
								}
							);	
						} else { //if the tag is not readable

						}
					});	
				});
			}
			catch (e) {
			}
			finally {
				setTimeout(updateData,document.getElementById("Rate").value);
			}
		}
	
		function updateTable()
		{
			//Get list of all tags and their properties from the database
			$.getJSON("tags", function(data){
				$.each(data, function(){groupList += '<option>'+this.groupName+'</option>';}); //cycle through groups and add them to dropdown
				$("#GroupSelect").html(groupList); //populate dropdown
				var group;
				var tbl_row="<tbody>";
				$("#ResultsTable tbody tr").remove();
				
				var index = 0;
				/*
				 * &index is used to keep track of master location in the group.
				 * TagBrowse returns an array of arrays, one for each datatype, so
				 * index is used to keep track of the table row. 
				 */
					
				//Get currently selected group
				group = $("#GroupSelect")[0].selectedIndex;
				
				
				if (group>=0) {				
					tagsDrawn=data[group].Tags;
					//Cycle through each tag group (organized by data type)
					$.each(tagsDrawn, function() {	
						var currtype = this.type; //get type of group
						
						$.each(this.tags, function(i,v){ //Cycle through each tag in the group
							index++; //increase index
							if (v.permissions == "R/W" || v.permissions == "R/-"){ //check for read permission
								tbl_row += "<tr><td>"+currtype+"</td><td>"+v.tagName+"</td><td>"+v.permissions+"</td><td id=\""+v.tagName+"\">"+"</td></tr>";
							} else { //if the tag is not readable
								tbl_row += "<tr><td>"+currtype+"</td><td>"+v.tagName+"</td><td>"+v.permissions+"</td><td id=\""+v.tagName+"\">"+"Read Access Denied"+"</td></tr>";
							}

						});	
					});
					tbl_row+="</tbody>";

					$("#ResultsTable > tbody").replaceWith(tbl_row);
				}
				else
				{
					setTimeout(updateTable,1000);
				}				
			});
		}
	}
);
