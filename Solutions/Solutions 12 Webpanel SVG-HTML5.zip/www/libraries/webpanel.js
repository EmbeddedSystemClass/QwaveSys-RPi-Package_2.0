/*	WebPanel   . 

    Copyright 2010 Steven M. Marlow, Evexia LLC
	
	This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
	
	See the file named COPYING that is distributed with this program
*/

var wp; //webpanel object
 
window.onload = function ()	// Upon loading, the script will search the parent document for webpanel animation elements by class attribute                             
{
	//for sending webpanel msg from HTML parent if SVG is.
	//For Chrome, launch with switch -allow-file-access-from-files if using localhost for this to work
	top.wpSend = wpSend;
	
	//URL of the websocket server. 
	//Edit this address before serving to client, or leave it for demo mode on  single PC
	var wsURL="ws://192.168.5.1:81/";	
	
	// jquery the WebPanel objects by class attribute ".class" notation does not work for SVG or xml  must use class='classname'
	$WebPanel = $("[class='webpanel']");
    
	if ("WebSocket" in window)
	{
		// open webpanel websocket connection
		wp = new WebSocket(wsURL);
		wp.binaryType = "arraybuffer";
		var packets = 0;
		
		wp.onopen = function()
		{
			// Webpanel is connected. Send metadata description of top-level elements
			// wp.send
		};

		wp.onmessage = function(evt)
		{
			//handle websocket message. update attributes or values of elements that match the id on incoming message
			var wpMsg = JSON.parse(evt.data); //parse JSON message
			$wpObject = $WebPanel.filter("#" + wpMsg.id); //query for target
			if ($wpObject.length > 0) //check to see if target oject contains data (element exists)
			{
				wpObjData = $wpObject.data("webpanel");
				switch(wpMsg.type)
				{
					case "value":
						switch (wpObjData.type)
						{
							case "meter":
							$needle = $wpObject.find("[class='needle']");
							$center = $wpObject.find("[class='centerRotation']");
							$wpObject.find("[class='textValue']").get(0).textContent = wpMsg.data;
							var rotation = wpMsg.data * wpObjData.slope + wpObjData.offset;
							$needle.attr("transform","rotate(" + rotation + "," + $center.attr("cx") + "," + $center.attr("cy") + ")");
							break;
							
							case "graphXY":
							var X = wpObjData.originX + ((wpMsg.data.x[0])*(wpObjData.width/(wpObjData.maxX-wpObjData.minX)));
							var Y = wpObjData.originY + ((wpMsg.data.y[0])*(wpObjData.height/(wpObjData.maxY-wpObjData.minY))*(-1));
							var dValue = "m " + X + "," + Y;
							var pX = X;
							var pY = Y;
							for (i=1; i<=wpMsg.data.x.length; i++)
							{
								X = wpObjData.originX + ((wpMsg.data.x[i])*(wpObjData.width/(wpObjData.maxX-wpObjData.minX)));
								Y = wpObjData.originY + ((wpMsg.data.y[i])*(wpObjData.height/(wpObjData.maxY-wpObjData.minY))*(-1));
								var dX = X - pX;
								var dY = Y - pY;
								dValue = dValue + " " + dX + "," + dY;
								pX = X;
								pY = Y;
							}
							$wpObject.find("[class='graphLine']").attr("d", dValue);
							break;
							
							//switch two-pic boolean view by swapping child order
							case "boolean":
							var boolValue = parseInt(wpMsg.data);
							var picOnId = indicator.getAttribute("wp:onId");
							var picOn = document.getElementById(picOnId);
							var picOffId = indicator.getAttribute("wp:offId");
							var picOff = document.getElementById(picOffId);
							indicator.appendChild(ledValue?picOn:picOff); //move child view to the end so it is on top
							indicator.setAttribute("wp:value", boolValue);
							break;

							//switch led by changing background light color and on/off text
							case "led":
							var ledColor = wpMsg.data? wpObjData.onColor : wpObjData.offColor;
							$wpObject.find("[class='ledLight']").css("fill", ledColor);
							$wpObject.find("[class='textLed']").get(0).textContent = wpMsg.data? wpObjData.onText : wpObjData.offText;
							break;
							
							//update horizontal progress bar width
							case "progressHorizontal":
							$wpObject.find("[class='progressBar']").attr("width", wpMsg.data);
							break;
							
							//update vertical progress bar height
							case "progressVertical":
							$progress = $wpObject.find("[class='progressBar']");
							$progress.attr("height",wpMsg.data);
							$progress.attr("y",(100 - parseInt(wpMsg.data)));
							break;
							
							//update an image
							case "image":
							var imgSRC="data:image/png;base64," + wpMsg.data;
							$wpObject.attr("src", imgSRC);
							break;
							
							//update HTML text
							case "htmlText":
							$wpObject.get(0).innerHTML = wpMsg.data;
							
							
							default:
							break;
						}
					break;
					
					case "attribute":
					break;
					
					default:
					break;
				}
			}
		};
		
		wp.onclose = function()
		{ 
			// websocket is closed.
			alert("Connection with " + wsURL + " was closed.");
			//alert(packets); debug code to show #packets received
		};
	}
	else
	{
		// The browser doesn't support WebSocket
		alert("WebSocket not supported by this Browser");
	}
}

function button(buttonId) //function for use by SVG buttons when they are clicked. execute using the onClick function of the SVG object
{
	var buttonObj = document.getElementById(buttonId); 
	var buttonValue = (!(parseInt(buttonObj.getAttribute("wp:value"))))?1:0;
	wp.send(buttonId + "|" + buttonValue);
	buttonObj.appendChild(buttonObj.childNodes[0]);
	var latch = parseInt(buttonObj.getAttribute("wp:latch"));
	if (latch)
	{
		var latchTime = parseInt(buttonObj.getAttribute("wp:latchTime"));
		var t=setTimeout("document.getElementById('" + buttonId + "').appendChild(document.getElementById('" + buttonId + "').childNodes[0]);",latchTime);
	}
	else
	{
	buttonObj.setAttribute("wp:value", buttonValue);
	}
}

function onOff(onOffId)
{
	var onOffObj = document.getElementById(onOffId); 
	var onOffValue = (!(parseInt(onOffObj.getAttribute("wp:value"))))?1:0;
	wp.send(onOffId + "|" + onOffValue);
	onOffObj.appendChild(onOffObj.childNodes[0]);
	onOffObj.setAttribute("wp:value", onOffValue);
}

function wpSend(txt)  //function for sending text from HTML document form objects when script is embedded
{
	wp.send(txt);
}
